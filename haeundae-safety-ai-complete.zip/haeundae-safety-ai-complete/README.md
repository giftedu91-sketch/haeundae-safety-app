# 해운대 해양안전 AI 앱 완성 프로젝트

## 폴더 구조

- `frontend/index.html`: GitHub Pages에 올릴 웹 앱
- `server/main.py`: YOLO `best.pt`를 실행하는 FastAPI 서버
- `server/best.pt`: 사용자가 Colab에서 학습해 받은 모델(직접 넣어야 함)

## 1. best.pt 넣기

다운로드 폴더에 있는 `best.pt`를 `server` 폴더 안으로 복사합니다.

```text
server/
├─ main.py
├─ requirements.txt
└─ best.pt
```

## 2. 컴퓨터에서 서버 시험하기

Windows PowerShell에서 프로젝트의 `server` 폴더로 이동한 뒤 실행합니다.

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```

브라우저에서 `http://localhost:8000/health`를 열었을 때 `model_exists: true`가 나오면 정상입니다.

## 3. 웹 앱 시험하기

`frontend/index.html`을 바로 더블클릭하지 말고, 별도 터미널에서 아래처럼 실행합니다.

```powershell
cd frontend
python -m http.server 5500
```

브라우저에서 `http://localhost:5500`을 엽니다.

## 4. 실제 인터넷 앱으로 배포하기

GitHub Pages는 Python과 `best.pt`를 실행할 수 없습니다. 따라서:

1. `server`를 Render 같은 Python/Docker 호스팅에 배포합니다.
2. 배포된 서버 주소가 예를 들어 `https://example.onrender.com`이라면,
3. `frontend/index.html`에서 아래 줄을 찾습니다.

```javascript
const API_BASE_URL = "http://localhost:8000";
```

아래처럼 바꿉니다.

```javascript
const API_BASE_URL = "https://example.onrender.com";
```

4. 수정한 `frontend/index.html`을 GitHub 저장소의 `index.html`로 올립니다.

## 주의

현재 Colab에서 사용한 공개 Aquarium 데이터셋은 해운대 위험 생물 전용 데이터셋이 아닐 수 있습니다. 모델의 클래스 이름에 따라 앱이 일반 탐지 결과를 표시할 수 있습니다. 정확한 노무라입깃해파리·보름달물해파리·파란고리문어·쏠배감펭 판별을 위해서는 해당 생물 사진으로 다시 학습해야 합니다.
